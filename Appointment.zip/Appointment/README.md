    			<div class="order">
    				<div class="head">
    					<h3>Reports</h3>
    					<i class='bx bx-search' ></i>
    					<i class='bx bx-filter' ></i>
    				</div>
    				<table>
    					<thead>
    						<tr>
    							<th>User</th>
    							<th>Date Order</th>
    							<th>Status</th>
    						</tr>
    					</thead>
    					<tbody>
    						<tr>
    							<td>
    								<img src="img/people.png">
    								<p>John Doe</p>
    							</td>
    							<td>01-10-2021</td>
    							<td><span class="status completed">Completed</span></td>
    						</tr>
    						<tr>
    							<td>
    								<img src="img/people.png">
    								<p>John Doe</p>
    							</td>
    							<td>01-10-2021</td>
    							<td><span class="status pending">Pending</span></td>
    						</tr>
    						<tr>
    							<td>
    								<img src="img/people.png">
    								<p>John Doe</p>
    							</td>
    							<td>01-10-2021</td>
    							<td><span class="status process">Process</span></td>
    						</tr>
    						<tr>
    							<td>
    								<img src="img/people.png">
    								<p>John Doe</p>
    							</td>
    							<td>01-10-2021</td>
    							<td><span class="status pending">Pending</span></td>
    						</tr>
    						<tr>
    							<td>
    								<img src="img/people.png">
    								<p>John Doe</p>
    							</td>
    							<td>01-10-2021</td>
    							<td><span class="status completed">Completed</span></td>
    						</tr>
    					</tbody>
    				</table>
    			</div>





                #content main .table-data .order {
    flex-grow: 1;
    flex-basis: 500px;

}
#content main .table-data .order table {
width: 100%;
border-collapse: collapse;
}
#content main .table-data .order table th {
padding-bottom: 12px;
font-size: 13px;
text-align: left;
border-bottom: 1px solid var(--grey);
}
#content main .table-data .order table td {
padding: 16px 0;
}
#content main .table-data .order table tr td:first-child {
display: flex;
align-items: center;
grid-gap: 12px;
padding-left: 6px;
}
#content main .table-data .order table td img {
width: 36px;
height: 36px;
border-radius: 50%;
object-fit: cover;
}
#content main .table-data .order table tbody tr:hover {
background: var(--grey);
}
#content main .table-data .order table tr td .status {
font-size: 10px;
padding: 6px 16px;
color: var(--light);
border-radius: 20px;
font-weight: 700;
}
#content main .table-data .order table tr td .status.completed {
background: var(--blue);
}
#content main .table-data .order table tr td .status.process {
background: var(--yellow);
}
#content main .table-data .order table tr td .status.pending {
background: var(--orange);
}
